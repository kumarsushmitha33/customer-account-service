package com.example.pension.account.domain;
import lombok.*;
import javax.persistence.*;
import java.math.BigDecimal;

@Entity @Table(name="accounts")
@Data @NoArgsConstructor
public class Account {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  private Long customerId;
  @Column(unique = true) private String accountNumber;
  private BigDecimal balance;
  private String currency;
  @Version private Long version;
}
