package com.example.pension.payment.repo;
import com.example.pension.payment.domain.PensionTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PensionTxnRepository extends JpaRepository<PensionTransaction, Long> {
  Optional<PensionTransaction> findByRequestId(String requestId);
}
