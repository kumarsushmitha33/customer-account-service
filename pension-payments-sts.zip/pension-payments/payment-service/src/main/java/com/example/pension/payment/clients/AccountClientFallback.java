package com.example.pension.payment.clients;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;

@Component
public class AccountClientFallback implements AccountClient {
  @Override
  public ResponseEntity<?> credit(String accountNo, BigDecimal amount){
    return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body("Account service unavailable");
  }
}
