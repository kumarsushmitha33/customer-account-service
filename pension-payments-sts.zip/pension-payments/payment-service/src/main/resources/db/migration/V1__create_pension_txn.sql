CREATE TABLE IF NOT EXISTS pension_transactions (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  customer_id BIGINT NOT NULL,
  account_number VARCHAR(32) NOT NULL,
  amount DECIMAL(19,2) NOT NULL,
  month_year CHAR(7) NOT NULL,
  status VARCHAR(20) NOT NULL,
  request_id VARCHAR(64) UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_txn_customer_month ON pension_transactions(customer_id, month_year);
