package com.example.pension.gateway.filters;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import io.jsonwebtoken.*;
import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;
import java.nio.charset.StandardCharsets;
import java.util.Date;

@Component
public class JwtAuthFilter extends ZuulFilter {
  private final String secretKey = "mySecretKeyForJwtValidation";
  @Override public String filterType(){ return "pre"; }
  @Override public int filterOrder(){ return 0; }
  @Override public boolean shouldFilter(){ return true; }
  @Override public Object run(){
    RequestContext ctx = RequestContext.getCurrentContext();
    HttpServletRequest request = ctx.getRequest();
    String path = request.getRequestURI();
    // Allow auth endpoint without token
    if (path != null && path.startsWith("/auth/")) return null;

    String authHeader = request.getHeader("Authorization");
    if (authHeader == null || !authHeader.startsWith("Bearer ")) {
      ctx.setSendZuulResponse(false); ctx.setResponseStatusCode(401);
      ctx.setResponseBody("Missing or invalid Authorization header");
      return null;
    }
    String token = authHeader.substring(7);
    try {
      Claims claims = Jwts.parser()
              .setSigningKey(secretKey.getBytes(StandardCharsets.UTF_8))
              .parseClaimsJws(token)
              .getBody();
      ctx.addZuulRequestHeader("X-User-Id", claims.getSubject());
      Object role = claims.get("role");
      if (role != null) ctx.addZuulRequestHeader("X-Role", role.toString());
    } catch (JwtException e){
      ctx.setSendZuulResponse(false); ctx.setResponseStatusCode(401);
      ctx.setResponseBody("Invalid JWT token");
    }
    return null;
  }
}
