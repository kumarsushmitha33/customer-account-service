package com.example.pension.gateway.web;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.web.bind.annotation.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

@RestController
@RequestMapping("/auth")
public class AuthController {
  private final String secretKey = "mySecretKeyForJwtValidation";

  @PostMapping("/token")
  public Map<String,String> generate(@RequestParam String userId, @RequestParam String role){
    String token = Jwts.builder()
            .setSubject(userId)
            .claim("role", role)
            .setIssuedAt(new Date())
            .setExpiration(new Date(System.currentTimeMillis() + 60*60*1000))
            .signWith(SignatureAlgorithm.HS256, secretKey.getBytes(StandardCharsets.UTF_8))
            .compact();
    return Collections.singletonMap("token", token);
  }
}
