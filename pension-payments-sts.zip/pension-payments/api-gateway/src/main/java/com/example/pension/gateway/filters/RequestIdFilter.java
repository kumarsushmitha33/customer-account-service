package com.example.pension.gateway.filters;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;
import java.util.Optional;
import java.util.UUID;

@Component
public class RequestIdFilter extends ZuulFilter {
  @Override public String filterType(){ return "pre"; }
  @Override public int filterOrder(){ return 1; }
  @Override public boolean shouldFilter(){ return true; }
  @Override public Object run(){
    RequestContext ctx = RequestContext.getCurrentContext();
    HttpServletRequest req = ctx.getRequest();
    String rid = Optional.ofNullable(req.getHeader("X-Request-Id")).orElse(UUID.randomUUID().toString());
    ctx.addZuulRequestHeader("X-Request-Id", rid);
    return null;
  }
}
