# Pension Payments — Netflix OSS + Kafka + MySQL (STS Import)

**Modules**: discovery-server, api-gateway, customer-service, account-service, payment-service

## Prereqs
- Java 17, Maven 3.8+
- Docker Desktop (for MySQL + Kafka + Zookeeper)

## Start Infra
```bash
cd docker
docker compose up -d
```
Creates MySQL (root/root), DBs, Zookeeper, Kafka.

## Run Services (order)
1. discovery-server — `mvn -pl discovery-server spring-boot:run`
2. api-gateway — `mvn -pl api-gateway spring-boot:run`
3. customer-service — `mvn -pl customer-service spring-boot:run`
4. account-service — `mvn -pl account-service spring-boot:run`
5. payment-service — `mvn -pl payment-service spring-boot:run`

Eureka: http://localhost:8761

## JWT Quick Test
1. Get token:
```bash
curl -X POST "http://localhost:8080/auth/token?userId=1001&role=ADMIN"
```
Copy the `"token"` value.

2. Create customer (through Zuul + JWT):
```bash
TOKEN=... # paste
curl -X POST http://localhost:8080/api/customers \\
  -H "Authorization: Bearer $TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{"name":"Sushmitha Kumar","dob":"1994-05-01","pan":"ABCDE1234F","email":"sushi@example.com","phone":"9000000000"}'
```

3. Insert an account (SQL) then pay pension:
```sql
INSERT INTO account_db.accounts(customer_id, account_number, balance, currency) VALUES (1,'ACC-001',0,'INR');
```
```bash
curl -X POST "http://localhost:8080/api/payments/pension?customerId=1&accountNo=ACC-001&amount=12000&monthYear=2025-10" \\
  -H "Authorization: Bearer $TOKEN" \\
  -H "Idempotency-Key: 2025-10-ACC-001"
```

Kafka will receive `payment.posted` on topic **payment.posted**.

## Notes
- Zuul injects `X-User-Id` and `X-Role` to downstream services.
- Hystrix fallback for account credit in payment-service.
- Ribbon load-balancing via Eureka (run multiple account-service instances to see it).

> For production: use asymmetric keys (RSA) for JWT, store secrets in Vault/KMS, and prefer Spring Cloud Gateway + Resilience4j on Boot 3.x.
