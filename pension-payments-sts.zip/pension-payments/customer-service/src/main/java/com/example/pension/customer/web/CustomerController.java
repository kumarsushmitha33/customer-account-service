package com.example.pension.customer.web;
import com.example.pension.customer.domain.Customer;
import com.example.pension.customer.repo.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.util.Optional;

@RestController @RequestMapping("/customers")
@RequiredArgsConstructor
public class CustomerController {
  private final CustomerRepository repo;
  @PostMapping public ResponseEntity<Customer> create(@RequestBody @Valid Customer c){
    return ResponseEntity.status(HttpStatus.CREATED).body(repo.save(c));
  }
  @GetMapping("/{id}") public ResponseEntity<Customer> get(@PathVariable Long id){
    Optional<Customer> c = repo.findById(id);
    return c.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
  }
}
