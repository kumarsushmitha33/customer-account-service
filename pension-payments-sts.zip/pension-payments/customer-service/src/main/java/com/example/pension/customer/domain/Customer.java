package com.example.pension.customer.domain;
import lombok.*;
import javax.persistence.*;
import java.time.LocalDate;

@Entity @Table(name="customers")
@Data @NoArgsConstructor @AllArgsConstructor
public class Customer {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  private String name;
  private LocalDate dob;
  @Column(unique = true) private String pan;
  @Column(unique = true) private String email;
  private String phone;
}
