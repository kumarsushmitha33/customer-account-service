package com.example.pension.customer.repo;
import com.example.pension.customer.domain.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
public interface CustomerRepository extends JpaRepository<Customer, Long> {
  Optional<Customer> findByPan(String pan);
}
